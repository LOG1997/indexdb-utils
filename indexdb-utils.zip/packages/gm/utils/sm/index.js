module.exports = {
  sm2: require('./sm2/index'),
  sm3: require('./sm3/index'),
  sm4: require('./sm4/index'),
};
