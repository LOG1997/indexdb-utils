export interface DbData{
    [key:string]: any
}